This directory contains a synthetic JAR (`fakejar.jar`) that is needed for `org.testcontainers.utility.MountableFileTest`.

The `create_fakejar.sh` script may be used to recreate it.