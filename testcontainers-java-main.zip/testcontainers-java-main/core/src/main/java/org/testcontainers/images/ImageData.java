package org.testcontainers.images;

import com.github.dockerjava.api.command.InspectImageResponse;
import com.github.dockerjava.api.model.Image;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

import java.time.Instant;
import java.time.ZonedDateTime;

@Value
@Builder
public class ImageData {

    @NonNull
    Instant createdAt;

    static ImageData from(InspectImageResponse inspectImageResponse) {
        final String created = inspectImageResponse.getCreated();
        final Instant createdInstant = ((created == null) || created.isEmpty())
            ? Instant.EPOCH
            : ZonedDateTime.parse(created).toInstant();
        return ImageData.builder().createdAt(createdInstant).build();
    }

    static ImageData from(Image image) {
        final Long created = image.getCreated();
        final Instant createdInstant = (created == null) ? Instant.EPOCH : Instant.ofEpochSecond(created);
        return ImageData.builder().createdAt(createdInstant).build();
    }
}
