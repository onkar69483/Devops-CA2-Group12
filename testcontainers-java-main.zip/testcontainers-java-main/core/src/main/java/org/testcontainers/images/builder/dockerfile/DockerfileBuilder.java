package org.testcontainers.images.builder.dockerfile;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.testcontainers.images.builder.dockerfile.statement.Statement;
import org.testcontainers.images.builder.dockerfile.traits.AddStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.CmdStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.CopyStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.DockerfileBuilderTrait;
import org.testcontainers.images.builder.dockerfile.traits.EntryPointStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.EnvStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.ExposeStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.FromStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.LabelStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.RunStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.UserStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.VolumeStatementTrait;
import org.testcontainers.images.builder.dockerfile.traits.WorkdirStatementTrait;

import java.util.ArrayList;
import java.util.List;

@Data
@Slf4j
public class DockerfileBuilder
    implements
        DockerfileBuilderTrait<DockerfileBuilder>,
        FromStatementTrait<DockerfileBuilder>,
        AddStatementTrait<DockerfileBuilder>,
        CopyStatementTrait<DockerfileBuilder>,
        RunStatementTrait<DockerfileBuilder>,
        CmdStatementTrait<DockerfileBuilder>,
        WorkdirStatementTrait<DockerfileBuilder>,
        EnvStatementTrait<DockerfileBuilder>,
        LabelStatementTrait<DockerfileBuilder>,
        ExposeStatementTrait<DockerfileBuilder>,
        EntryPointStatementTrait<DockerfileBuilder>,
        VolumeStatementTrait<DockerfileBuilder>,
        UserStatementTrait<DockerfileBuilder> {

    private final List<Statement> statements = new ArrayList<>();

    public String build() {
        StringBuilder builder = new StringBuilder();

        for (Statement statement : statements) {
            builder.append(statement.getType());
            builder.append(" ");
            statement.appendArguments(builder);
            builder.append("\n");
        }

        String result = builder.toString();

        log.debug("Returning Dockerfile:\n{}", result);

        return result;
    }
}
