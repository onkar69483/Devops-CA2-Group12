package org.testcontainers.containers;

public class ParsedDockerComposeFileBean {

    public String foo;

    public ParsedDockerComposeFileBean(String foo) {
        this.foo = foo;
    }
}
