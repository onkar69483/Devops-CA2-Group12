#!/bin/ash

set -ex

sleep 2
touch /testfile

while true; do sleep 1; done
